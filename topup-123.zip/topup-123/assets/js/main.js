// ===== MAIN JAVASCRIPT FILE =====
// TopUp System - Static HTML Version
// This file contains all the client-side functionality

// ===== GLOBAL VARIABLES =====
let currentUser = null;
let isLoggedIn = false;
let userRole = 'guest';

// ===== UTILITY FUNCTIONS =====

// Show message to user
function showMessage(message, type = 'info', duration = 3000) {
    // Remove existing messages
    const existingMessages = document.querySelectorAll('.message');
    existingMessages.forEach(msg => msg.remove());
    
    // Create new message element
    const messageEl = document.createElement('div');
    messageEl.className = `message ${type}`;
    messageEl.textContent = message;
    
    // Add to page
    document.body.appendChild(messageEl);
    
    // Auto remove after duration
    setTimeout(() => {
        if (messageEl.parentNode) {
            messageEl.remove();
        }
    }, duration);
}

// Format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

// Format date
function formatDate(date) {
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    }).format(new Date(date));
}

// Format relative time
function formatRelativeTime(date) {
    const now = new Date();
    const past = new Date(date);
    const diffInSeconds = Math.floor((now - past) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} days ago`;
    return formatDate(date);
}

// Generate random ID
function generateId() {
    return Math.random().toString(36).substr(2, 9);
}

// Validate email
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Validate phone number
function validatePhone(phone) {
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
}

// ===== LOCAL STORAGE FUNCTIONS =====

// Save to localStorage
function saveToStorage(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
        return true;
    } catch (error) {
        console.error('Error saving to localStorage:', error);
        return false;
    }
}

// Load from localStorage
function loadFromStorage(key) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    } catch (error) {
        console.error('Error loading from localStorage:', error);
        return null;
    }
}

// Remove from localStorage
function removeFromStorage(key) {
    try {
        localStorage.removeItem(key);
        return true;
    } catch (error) {
        console.error('Error removing from localStorage:', error);
        return false;
    }
}

// ===== USER MANAGEMENT =====

// Initialize demo users
function initializeDemoUsers() {
    const demoUsers = [
        {
            id: 'user1',
            email: 'user@demo.com',
            password: 'demo123',
            fullName: 'John Doe',
            phone: '+1 (555) 123-4567',
            role: 'user',
            balance: 50.00,
            totalTransactions: 24,
            totalSpent: 120.00,
            totalCashback: 12.50,
            isActive: true,
            createdAt: '2024-01-10',
            lastLoginAt: new Date().toISOString()
        },
        {
            id: 'admin1',
            email: 'admin@demo.com',
            password: 'admin123',
            fullName: 'Administrator',
            phone: '+1 (555) 999-0000',
            role: 'admin',
            balance: 1000.00,
            totalTransactions: 0,
            totalSpent: 0,
            totalCashback: 0,
            isActive: true,
            createdAt: '2024-01-01',
            lastLoginAt: new Date().toISOString()
        }
    ];
    
    // Save demo users if not already saved
    if (!loadFromStorage('users')) {
        saveToStorage('users', demoUsers);
    }
}

// Get all users
function getAllUsers() {
    return loadFromStorage('users') || [];
}

// Get user by email
function getUserByEmail(email) {
    const users = getAllUsers();
    return users.find(user => user.email === email);
}

// Save user
function saveUser(user) {
    const users = getAllUsers();
    const existingIndex = users.findIndex(u => u.id === user.id);
    
    if (existingIndex >= 0) {
        users[existingIndex] = user;
    } else {
        users.push(user);
    }
    
    return saveToStorage('users', users);
}

// ===== AUTHENTICATION =====

// Login user
function loginUser(email, password) {
    const user = getUserByEmail(email);
    
    if (!user) {
        throw new Error('User not found');
    }
    
    if (user.password !== password) {
        throw new Error('Invalid password');
    }
    
    if (!user.isActive) {
        throw new Error('Account is deactivated');
    }
    
    // Update last login
    user.lastLoginAt = new Date().toISOString();
    saveUser(user);
    
    // Set current user
    currentUser = user;
    isLoggedIn = true;
    userRole = user.role;
    
    // Save session
    saveToStorage('currentUser', user);
    saveToStorage('isLoggedIn', true);
    
    return user;
}

// Register user
function registerUser(userData) {
    const users = getAllUsers();
    
    // Check if email already exists
    if (users.find(user => user.email === userData.email)) {
        throw new Error('Email already registered');
    }
    
    // Create new user
    const newUser = {
        id: generateId(),
        email: userData.email,
        password: userData.password,
        fullName: userData.fullName,
        phone: userData.phone,
        role: 'user',
        balance: 0.00,
        totalTransactions: 0,
        totalSpent: 0,
        totalCashback: 0,
        isActive: true,
        createdAt: new Date().toISOString(),
        lastLoginAt: null
    };
    
    // Save user
    if (saveUser(newUser)) {
        return newUser;
    } else {
        throw new Error('Failed to register user');
    }
}

// Logout user
function logoutUser() {
    currentUser = null;
    isLoggedIn = false;
    userRole = 'guest';
    
    removeFromStorage('currentUser');
    removeFromStorage('isLoggedIn');
    
    updateUIForAuthState();
}

// Check authentication state
function checkAuthState() {
    const savedUser = loadFromStorage('currentUser');
    const savedLoginState = loadFromStorage('isLoggedIn');
    
    if (savedUser && savedLoginState) {
        currentUser = savedUser;
        isLoggedIn = true;
        userRole = savedUser.role;
    }
    
    updateUIForAuthState();
}

// Update UI based on authentication state
function updateUIForAuthState() {
    const guestElements = document.querySelectorAll('.guest-only');
    const userElements = document.querySelectorAll('.user-only');
    const userNameElements = document.querySelectorAll('.user-name');
    
    if (isLoggedIn && currentUser) {
        // Hide guest elements
        guestElements.forEach(el => el.style.display = 'none');
        // Show user elements
        userElements.forEach(el => el.style.display = 'flex');
        // Update user name
        userNameElements.forEach(el => el.textContent = currentUser.fullName);
    } else {
        // Show guest elements
        guestElements.forEach(el => el.style.display = '');
        // Hide user elements
        userElements.forEach(el => el.style.display = 'none');
    }
}

// ===== TRANSACTION MANAGEMENT =====

// Initialize demo transactions
function initializeDemoTransactions() {
    const demoTransactions = [
        {
            id: 'TXN001',
            userId: 'user1',
            phoneNumber: '+1 (555) 123-4567',
            operator: 'AT&T',
            amount: 10.00,
            type: 'topup',
            status: 'completed',
            paymentMethod: 'balance',
            createdAt: '2024-01-15T14:30:00Z',
            updatedAt: '2024-01-15T14:30:30Z',
            completedAt: '2024-01-15T14:30:30Z'
        },
        {
            id: 'TXN002',
            userId: 'user1',
            phoneNumber: '+1 (555) 987-6543',
            operator: 'T-Mobile',
            amount: 20.00,
            type: 'topup',
            status: 'pending',
            paymentMethod: 'balance',
            createdAt: '2024-01-14T10:15:00Z',
            updatedAt: '2024-01-14T10:15:00Z',
            completedAt: null
        },
        {
            id: 'TXN003',
            userId: 'user1',
            phoneNumber: '+1 (555) 456-7890',
            operator: 'Verizon',
            amount: 5.00,
            type: 'topup',
            status: 'completed',
            paymentMethod: 'balance',
            createdAt: '2024-01-13T16:45:00Z',
            updatedAt: '2024-01-13T16:45:15Z',
            completedAt: '2024-01-13T16:45:15Z'
        }
    ];
    
    if (!loadFromStorage('transactions')) {
        saveToStorage('transactions', demoTransactions);
    }
}

// Get all transactions
function getAllTransactions() {
    return loadFromStorage('transactions') || [];
}

// Get user transactions
function getUserTransactions(userId) {
    const transactions = getAllTransactions();
    return transactions.filter(transaction => transaction.userId === userId);
}

// Create transaction
function createTransaction(transactionData) {
    const transactions = getAllTransactions();
    
    const newTransaction = {
        id: 'TXN' + String(Math.floor(Math.random() * 1000)).padStart(3, '0'),
        userId: currentUser.id,
        phoneNumber: transactionData.phoneNumber,
        operator: transactionData.operator,
        amount: parseFloat(transactionData.amount),
        type: 'topup',
        status: 'pending',
        paymentMethod: 'balance',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        completedAt: null
    };
    
    transactions.push(newTransaction);
    saveToStorage('transactions', transactions);
    
    // Simulate processing
    setTimeout(() => {
        processTransaction(newTransaction.id);
    }, 2000);
    
    return newTransaction;
}

// Process transaction
function processTransaction(transactionId) {
    const transactions = getAllTransactions();
    const transaction = transactions.find(t => t.id === transactionId);
    
    if (!transaction) return;
    
    // Update transaction status
    transaction.status = 'completed';
    transaction.updatedAt = new Date().toISOString();
    transaction.completedAt = new Date().toISOString();
    
    // Update user stats
    if (currentUser && currentUser.id === transaction.userId) {
        currentUser.totalTransactions += 1;
        currentUser.totalSpent += transaction.amount;
        currentUser.totalCashback += transaction.amount * 0.02; // 2% cashback
        currentUser.balance -= transaction.amount;
        
        saveUser(currentUser);
        saveToStorage('currentUser', currentUser);
    }
    
    saveToStorage('transactions', transactions);
    
    showMessage('Transaction completed successfully!', 'success');
}

// ===== FORM VALIDATION =====

// Validate form
function validateForm(formElement) {
    const inputs = formElement.querySelectorAll('input[required], select[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            isValid = false;
            input.classList.add('error');
        } else {
            input.classList.remove('error');
        }
        
        // Specific validations
        if (input.type === 'email' && input.value && !validateEmail(input.value)) {
            isValid = false;
            input.classList.add('error');
        }
        
        if (input.type === 'tel' && input.value && !validatePhone(input.value)) {
            isValid = false;
            input.classList.add('error');
        }
    });
    
    return isValid;
}

// ===== DROPDOWN FUNCTIONALITY =====

// Initialize dropdowns
function initializeDropdowns() {
    const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
    
    dropdownToggles.forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const dropdown = this.closest('.dropdown');
            const menu = dropdown.querySelector('.dropdown-menu');
            
            // Close other dropdowns
            document.querySelectorAll('.dropdown-menu.show').forEach(otherMenu => {
                if (otherMenu !== menu) {
                    otherMenu.classList.remove('show');
                }
            });
            
            // Toggle current dropdown
            menu.classList.toggle('show');
        });
    });
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', function() {
        document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
            menu.classList.remove('show');
        });
    });
}

// ===== NAVBAR FUNCTIONALITY =====

// Initialize navbar
function initializeNavbar() {
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarNav = document.querySelector('.navbar-nav');
    
    if (navbarToggler && navbarNav) {
        navbarToggler.addEventListener('click', function() {
            navbarNav.classList.toggle('show');
        });
    }
}

// ===== SMOOTH SCROLLING =====

// Initialize smooth scrolling for anchor links
function initializeSmoothScrolling() {
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href === '#' || href === '#logout') return;
            
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// ===== PRICING BUTTONS =====

// Initialize pricing buttons
function initializePricingButtons() {
    const pricingButtons = document.querySelectorAll('.pricing-btn');
    
    pricingButtons.forEach(button => {
        button.addEventListener('click', function() {
            const amount = this.dataset.amount;
            
            if (isLoggedIn) {
                // Redirect to dashboard with amount
                window.location.href = `user/index.html?amount=${amount}`;
            } else {
                showMessage('Please login to continue', 'info');
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 1000);
            }
        });
    });
}

// ===== ANIMATION OBSERVERS =====

// Initialize intersection observer for animations
function initializeAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observe elements that should animate
    const animateElements = document.querySelectorAll('.feature-card, .operator-card, .pricing-card, .stat-card');
    animateElements.forEach(el => observer.observe(el));
}

// ===== SEARCH FUNCTIONALITY =====

// Initialize search functionality
function initializeSearch() {
    const searchInputs = document.querySelectorAll('input[type="search"], .search-box input');
    
    searchInputs.forEach(input => {
        let searchTimeout;
        
        input.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                performSearch(this.value, this);
            }, 300);
        });
    });
}

// Perform search
function performSearch(query, inputElement) {
    const searchContainer = inputElement.closest('.admin-main, .dashboard-main');
    if (!searchContainer) return;
    
    const searchableElements = searchContainer.querySelectorAll('tr, .user-card, .transaction-card');
    
    searchableElements.forEach(element => {
        const text = element.textContent.toLowerCase();
        const matches = text.includes(query.toLowerCase());
        
        if (query === '' || matches) {
            element.style.display = '';
        } else {
            element.style.display = 'none';
        }
    });
}

// ===== CHART FUNCTIONALITY =====

// Initialize charts (placeholder for Chart.js integration)
function initializeCharts() {
    // This would be implemented with Chart.js in a real application
    console.log('Charts initialized');
}

// ===== REAL-TIME UPDATES =====

// Simulate real-time updates
function initializeRealTimeUpdates() {
    if (userRole === 'admin') {
        setInterval(() => {
            updateAdminStats();
        }, 30000); // Update every 30 seconds
    }
}

// Update admin stats
function updateAdminStats() {
    const statNumbers = document.querySelectorAll('.stat-number');
    
    statNumbers.forEach(stat => {
        if (stat.textContent.includes('$')) {
            // Update revenue
            const current = parseFloat(stat.textContent.replace(/[$,]/g, ''));
            const newValue = current + Math.floor(Math.random() * 100);
            stat.textContent = formatCurrency(newValue);
        } else if (stat.textContent === '23') {
            // Update pending transactions
            const newValue = Math.floor(Math.random() * 50);
            stat.textContent = newValue;
        }
    });
}

// ===== KEYBOARD SHORTCUTS =====

// Initialize keyboard shortcuts
function initializeKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + K for search
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            const searchInput = document.querySelector('input[type="search"], .search-box input');
            if (searchInput) {
                searchInput.focus();
            }
        }
        
        // Escape to close modals
        if (e.key === 'Escape') {
            const openModals = document.querySelectorAll('.modal[style*="flex"]');
            openModals.forEach(modal => {
                modal.style.display = 'none';
            });
        }
    });
}

// ===== FORM AUTO-SAVE =====

// Initialize form auto-save
function initializeFormAutoSave() {
    const forms = document.querySelectorAll('form[data-autosave]');
    
    forms.forEach(form => {
        const formId = form.id || 'form_' + generateId();
        
        // Load saved data
        const savedData = loadFromStorage(`form_${formId}`);
        if (savedData) {
            Object.keys(savedData).forEach(key => {
                const input = form.querySelector(`[name="${key}"]`);
                if (input) {
                    input.value = savedData[key];
                }
            });
        }
        
        // Save on input
        form.addEventListener('input', function() {
            const formData = new FormData(form);
            const data = {};
            for (let [key, value] of formData.entries()) {
                data[key] = value;
            }
            saveToStorage(`form_${formId}`, data);
        });
        
        // Clear on submit
        form.addEventListener('submit', function() {
            removeFromStorage(`form_${formId}`);
        });
    });
}

// ===== THEME MANAGEMENT =====

// Initialize theme management
function initializeTheme() {
    const savedTheme = loadFromStorage('theme') || 'light';
    applyTheme(savedTheme);
    
    // Theme toggle buttons
    const themeToggles = document.querySelectorAll('[data-theme-toggle]');
    themeToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            applyTheme(newTheme);
            saveToStorage('theme', newTheme);
        });
    });
}

// Apply theme
function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
}

// ===== ERROR HANDLING =====

// Global error handler
window.addEventListener('error', function(e) {
    console.error('Global error:', e.error);
    showMessage('An unexpected error occurred. Please try again.', 'error');
});

// Unhandled promise rejection handler
window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled promise rejection:', e.reason);
    showMessage('An unexpected error occurred. Please try again.', 'error');
});

// ===== PERFORMANCE MONITORING =====

// Initialize performance monitoring
function initializePerformanceMonitoring() {
    // Monitor page load time
    window.addEventListener('load', function() {
        const loadTime = performance.now();
        console.log(`Page loaded in ${loadTime.toFixed(2)}ms`);
    });
    
    // Monitor long tasks
    if ('PerformanceObserver' in window) {
        const observer = new PerformanceObserver((list) => {
            list.getEntries().forEach((entry) => {
                if (entry.duration > 50) {
                    console.warn(`Long task detected: ${entry.duration.toFixed(2)}ms`);
                }
            });
        });
        
        observer.observe({ entryTypes: ['longtask'] });
    }
}

// ===== INITIALIZATION =====

// Initialize application
function initializeApp() {
    console.log('Initializing TopUp System...');
    
    // Initialize demo data
    initializeDemoUsers();
    initializeDemoTransactions();
    
    // Check authentication state
    checkAuthState();
    
    // Initialize UI components
    initializeDropdowns();
    initializeNavbar();
    initializeSmoothScrolling();
    initializePricingButtons();
    initializeAnimations();
    initializeSearch();
    initializeCharts();
    initializeKeyboardShortcuts();
    initializeFormAutoSave();
    initializeTheme();
    initializeRealTimeUpdates();
    initializePerformanceMonitoring();
    
    console.log('TopUp System initialized successfully!');
}

// ===== DOM READY =====

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

// ===== EXPORT FOR MODULES =====

// Export functions for use in other scripts
window.TopUpSystem = {
    // Authentication
    loginUser,
    registerUser,
    logoutUser,
    checkAuthState,
    
    // User management
    getCurrentUser: () => currentUser,
    isUserLoggedIn: () => isLoggedIn,
    getUserRole: () => userRole,
    
    // Transactions
    createTransaction,
    getUserTransactions,
    getAllTransactions,
    
    // Utilities
    showMessage,
    formatCurrency,
    formatDate,
    formatRelativeTime,
    validateEmail,
    validatePhone,
    
    // Storage
    saveToStorage,
    loadFromStorage,
    removeFromStorage
};

