// ===== DASHBOARD JAVASCRIPT =====
// Handles user and admin dashboard functionality

// ===== DASHBOARD INITIALIZATION =====
function initializeDashboard() {
    // Check authentication
    if (!TopUpSystem.isUserLoggedIn()) {
        window.location.href = '../login.html';
        return;
    }
    
    const user = TopUpSystem.getCurrentUser();
    const userRole = TopUpSystem.getUserRole();
    
    // Update user info in UI
    updateUserInfo(user);
    
    // Initialize based on role
    if (userRole === 'admin') {
        initializeAdminDashboard();
    } else {
        initializeUserDashboard();
    }
    
    // Common dashboard features
    initializeCommonFeatures();
}

// ===== UPDATE USER INFO =====
function updateUserInfo(user) {
    // Update user name
    const userNameElements = document.querySelectorAll('.user-name');
    userNameElements.forEach(el => el.textContent = user.fullName);
    
    // Update user role
    const userRoleElements = document.querySelectorAll('.user-role');
    userRoleElements.forEach(el => el.textContent = user.role.charAt(0).toUpperCase() + user.role.slice(1));
    
    // Update balance
    const balanceElements = document.querySelectorAll('.balance-amount');
    balanceElements.forEach(el => el.textContent = TopUpSystem.formatCurrency(user.balance));
    
    // Update stats
    updateUserStats(user);
}

// ===== UPDATE USER STATS =====
function updateUserStats(user) {
    const stats = {
        balance: user.balance,
        transactions: user.totalTransactions,
        spent: user.totalSpent,
        cashback: user.totalCashback
    };
    
    Object.keys(stats).forEach(key => {
        const elements = document.querySelectorAll(`.stat-${key} .stat-number`);
        elements.forEach(el => {
            if (key === 'transactions') {
                el.textContent = stats[key];
            } else {
                el.textContent = TopUpSystem.formatCurrency(stats[key]);
            }
        });
    });
}

// ===== USER DASHBOARD =====
function initializeUserDashboard() {
    console.log('Initializing user dashboard...');
    
    // Initialize topup form
    initializeTopupForm();
    
    // Load user transactions
    loadUserTransactions();
    
    // Initialize quick actions
    initializeQuickActions();
}

// ===== TOPUP FORM =====
function initializeTopupForm() {
    const topupForm = document.getElementById('topupForm');
    if (!topupForm) return;
    
    // Amount buttons
    const amountButtons = document.querySelectorAll('.amount-btn');
    const customAmountInput = document.getElementById('customAmount');
    
    amountButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active class from all buttons
            amountButtons.forEach(b => b.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Set custom amount
            if (customAmountInput) {
                customAmountInput.value = this.textContent.replace('$', '');
            }
        });
    });
    
    // Form submission
    topupForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const transactionData = {
            phoneNumber: formData.get('phoneNumber'),
            operator: formData.get('operator'),
            amount: formData.get('amount') || customAmountInput?.value
        };
        
        // Validate form
        if (!transactionData.phoneNumber || !transactionData.operator || !transactionData.amount) {
            TopUpSystem.showMessage('Please fill in all fields', 'error');
            return;
        }
        
        const amount = parseFloat(transactionData.amount);
        const user = TopUpSystem.getCurrentUser();
        
        // Check balance
        if (amount > user.balance) {
            TopUpSystem.showMessage('Insufficient balance', 'error');
            return;
        }
        
        // Show loading
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Processing...';
        submitBtn.disabled = true;
        
        try {
            // Create transaction
            const transaction = TopUpSystem.createTransaction(transactionData);
            
            TopUpSystem.showMessage('Transaction initiated successfully!', 'success');
            
            // Reset form
            this.reset();
            amountButtons.forEach(b => b.classList.remove('active'));
            
            // Reload transactions
            setTimeout(() => {
                loadUserTransactions();
                updateUserInfo(TopUpSystem.getCurrentUser());
            }, 1000);
            
        } catch (error) {
            TopUpSystem.showMessage(error.message, 'error');
        } finally {
            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    });
}

// ===== LOAD USER TRANSACTIONS =====
function loadUserTransactions() {
    const user = TopUpSystem.getCurrentUser();
    const transactions = TopUpSystem.getUserTransactions(user.id);
    
    const transactionsTable = document.querySelector('.transactions-table tbody');
    if (!transactionsTable) return;
    
    // Clear existing rows
    transactionsTable.innerHTML = '';
    
    if (transactions.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="6" style="text-align: center; color: var(--gray-500);">
                No transactions found
            </td>
        `;
        transactionsTable.appendChild(row);
        return;
    }
    
    // Add transaction rows
    transactions.slice(0, 10).forEach(transaction => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${transaction.id}</td>
            <td>${transaction.phoneNumber}</td>
            <td>${transaction.operator}</td>
            <td>${TopUpSystem.formatCurrency(transaction.amount)}</td>
            <td>
                <span class="status-badge badge-${transaction.status === 'completed' ? 'success' : transaction.status === 'pending' ? 'warning' : 'danger'}">
                    ${transaction.status}
                </span>
            </td>
            <td>${TopUpSystem.formatRelativeTime(transaction.createdAt)}</td>
        `;
        transactionsTable.appendChild(row);
    });
}

// ===== QUICK ACTIONS =====
function initializeQuickActions() {
    const quickActionBtns = document.querySelectorAll('.quick-action-btn');
    
    quickActionBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const action = this.dataset.action;
            
            switch (action) {
                case 'topup':
                    document.getElementById('phoneNumber')?.focus();
                    break;
                case 'history':
                    document.querySelector('.transactions-section')?.scrollIntoView({ behavior: 'smooth' });
                    break;
                case 'profile':
                    TopUpSystem.showMessage('Profile management coming soon!', 'info');
                    break;
                case 'support':
                    TopUpSystem.showMessage('Support chat coming soon!', 'info');
                    break;
            }
        });
    });
}

// ===== ADMIN DASHBOARD =====
function initializeAdminDashboard() {
    console.log('Initializing admin dashboard...');
    
    // Load admin stats
    loadAdminStats();
    
    // Load all transactions
    loadAllTransactions();
    
    // Load all users
    loadAllUsers();
    
    // Initialize admin actions
    initializeAdminActions();
}

// ===== LOAD ADMIN STATS =====
function loadAdminStats() {
    const users = TopUpSystem.loadFromStorage('users') || [];
    const transactions = TopUpSystem.getAllTransactions();
    
    // Calculate stats
    const totalUsers = users.length;
    const activeUsers = users.filter(u => u.isActive).length;
    const totalRevenue = transactions.reduce((sum, t) => sum + (t.status === 'completed' ? t.amount : 0), 0);
    const pendingTransactions = transactions.filter(t => t.status === 'pending').length;
    
    // Update UI
    updateAdminStat('users', totalUsers);
    updateAdminStat('active', activeUsers);
    updateAdminStat('revenue', totalRevenue);
    updateAdminStat('pending', pendingTransactions);
}

function updateAdminStat(type, value) {
    const elements = document.querySelectorAll(`.stat-${type} .stat-number`);
    elements.forEach(el => {
        if (type === 'revenue') {
            el.textContent = TopUpSystem.formatCurrency(value);
        } else {
            el.textContent = value;
        }
    });
}

// ===== LOAD ALL TRANSACTIONS =====
function loadAllTransactions() {
    const transactions = TopUpSystem.getAllTransactions();
    const transactionsTable = document.querySelector('.admin-table tbody');
    
    if (!transactionsTable) return;
    
    // Clear existing rows
    transactionsTable.innerHTML = '';
    
    if (transactions.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="7" style="text-align: center; color: var(--gray-500);">
                No transactions found
            </td>
        `;
        transactionsTable.appendChild(row);
        return;
    }
    
    // Add transaction rows
    transactions.slice(0, 20).forEach(transaction => {
        const user = TopUpSystem.loadFromStorage('users')?.find(u => u.id === transaction.userId);
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${transaction.id}</td>
            <td>
                <div class="user-info">
                    <img src="../assets/images/user-avatar.png" alt="User" class="user-avatar-sm">
                    <div>
                        <div class="user-name">${user?.fullName || 'Unknown'}</div>
                        <div class="user-role">${user?.email || 'N/A'}</div>
                    </div>
                </div>
            </td>
            <td>${transaction.phoneNumber}</td>
            <td>${transaction.operator}</td>
            <td>${TopUpSystem.formatCurrency(transaction.amount)}</td>
            <td>
                <span class="status-badge badge-${transaction.status === 'completed' ? 'success' : transaction.status === 'pending' ? 'warning' : 'danger'}">
                    ${transaction.status}
                </span>
            </td>
            <td>${TopUpSystem.formatRelativeTime(transaction.createdAt)}</td>
        `;
        transactionsTable.appendChild(row);
    });
}

// ===== LOAD ALL USERS =====
function loadAllUsers() {
    const usersTable = document.querySelector('.users-table tbody');
    if (!usersTable) return;
    
    const users = TopUpSystem.loadFromStorage('users') || [];
    
    // Clear existing rows
    usersTable.innerHTML = '';
    
    if (users.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="6" style="text-align: center; color: var(--gray-500);">
                No users found
            </td>
        `;
        usersTable.appendChild(row);
        return;
    }
    
    // Add user rows
    users.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <div class="user-info">
                    <img src="../assets/images/user-avatar.png" alt="User" class="user-avatar-sm">
                    <div class="user-details">
                        <div class="user-name">${user.fullName}</div>
                        <div class="user-role">${user.role}</div>
                    </div>
                </div>
            </td>
            <td>${user.email}</td>
            <td>${user.phone}</td>
            <td>${TopUpSystem.formatCurrency(user.balance)}</td>
            <td>
                <span class="status-badge badge-${user.isActive ? 'success' : 'danger'}">
                    ${user.isActive ? 'Active' : 'Inactive'}
                </span>
            </td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-sm btn-outline-primary" onclick="editUser('${user.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-${user.isActive ? 'danger' : 'success'}" onclick="toggleUserStatus('${user.id}')">
                        <i class="fas fa-${user.isActive ? 'ban' : 'check'}"></i>
                    </button>
                </div>
            </td>
        `;
        usersTable.appendChild(row);
    });
}

// ===== ADMIN ACTIONS =====
function initializeAdminActions() {
    // Quick action cards
    const quickActionCards = document.querySelectorAll('.quick-action-card');
    
    quickActionCards.forEach(card => {
        card.addEventListener('click', function() {
            const action = this.dataset.action;
            
            switch (action) {
                case 'users':
                    window.location.href = 'users.html';
                    break;
                case 'transactions':
                    document.querySelector('.admin-table-card')?.scrollIntoView({ behavior: 'smooth' });
                    break;
                case 'reports':
                    TopUpSystem.showMessage('Reports feature coming soon!', 'info');
                    break;
                case 'settings':
                    TopUpSystem.showMessage('Settings panel coming soon!', 'info');
                    break;
            }
        });
    });
}

// ===== USER MANAGEMENT FUNCTIONS =====
window.editUser = function(userId) {
    TopUpSystem.showMessage('User editing feature coming soon!', 'info');
};

window.toggleUserStatus = function(userId) {
    const users = TopUpSystem.loadFromStorage('users') || [];
    const user = users.find(u => u.id === userId);
    
    if (!user) return;
    
    const action = user.isActive ? 'deactivate' : 'activate';
    
    if (confirm(`Are you sure you want to ${action} this user?`)) {
        user.isActive = !user.isActive;
        TopUpSystem.saveToStorage('users', users);
        
        TopUpSystem.showMessage(`User ${action}d successfully!`, 'success');
        
        // Reload users table
        loadAllUsers();
        loadAdminStats();
    }
};

// ===== COMMON FEATURES =====
function initializeCommonFeatures() {
    // Real-time updates
    setInterval(() => {
        const user = TopUpSystem.getCurrentUser();
        if (user) {
            updateUserInfo(user);
            
            if (user.role === 'admin') {
                loadAdminStats();
            }
        }
    }, 30000); // Update every 30 seconds
    
    // Auto-refresh transactions
    setInterval(() => {
        if (TopUpSystem.getUserRole() === 'admin') {
            loadAllTransactions();
        } else {
            loadUserTransactions();
        }
    }, 60000); // Update every minute
}

// ===== SIDEBAR NAVIGATION =====
function initializeSidebarNavigation() {
    const sidebarLinks = document.querySelectorAll('.sidebar-nav .nav-link');
    const currentPath = window.location.pathname;
    
    sidebarLinks.forEach(link => {
        const href = link.getAttribute('href');
        
        if (currentPath.includes(href)) {
            link.classList.add('active');
        }
        
        link.addEventListener('click', function(e) {
            // Remove active class from all links
            sidebarLinks.forEach(l => l.classList.remove('active'));
            
            // Add active class to clicked link
            this.classList.add('active');
        });
    });
}

// ===== CHARTS INITIALIZATION =====
function initializeCharts() {
    // This would integrate with Chart.js in a real application
    console.log('Charts would be initialized here with Chart.js');
}

// ===== EXPORT FUNCTIONS =====
window.DashboardSystem = {
    initializeDashboard,
    loadUserTransactions,
    loadAllTransactions,
    loadAllUsers,
    updateUserInfo,
    loadAdminStats
};

// ===== INITIALIZATION =====
function initializeDashboardModule() {
    initializeDashboard();
    initializeSidebarNavigation();
    initializeCharts();
    
    console.log('Dashboard module initialized');
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeDashboardModule);
} else {
    initializeDashboardModule();
}

