// ===== AUTHENTICATION JAVASCRIPT =====
// Handles login, registration, and authentication forms

// ===== LOGIN FORM HANDLER =====
function handleLoginForm() {
    const loginForm = document.getElementById('loginForm');
    if (!loginForm) return;
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const rememberMe = document.getElementById('rememberMe')?.checked || false;
        
        // Show loading state
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Signing In...';
        submitBtn.disabled = true;
        
        try {
            // Attempt login
            const user = TopUpSystem.loginUser(email, password);
            
            TopUpSystem.showMessage('Login successful! Redirecting...', 'success');
            
            // Redirect based on user role
            setTimeout(() => {
                if (user.role === 'admin') {
                    window.location.href = 'admin/index.html';
                } else {
                    window.location.href = 'user/index.html';
                }
            }, 1000);
            
        } catch (error) {
            TopUpSystem.showMessage(error.message, 'error');
            
            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    });
}

// ===== REGISTRATION FORM HANDLER =====
function handleRegistrationForm() {
    const registerForm = document.getElementById('registerForm');
    if (!registerForm) return;
    
    registerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const userData = {
            fullName: formData.get('fullName'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            password: formData.get('password')
        };
        
        const confirmPassword = formData.get('confirmPassword');
        
        // Validate passwords match
        if (userData.password !== confirmPassword) {
            TopUpSystem.showMessage('Passwords do not match', 'error');
            return;
        }
        
        // Show loading state
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Creating Account...';
        submitBtn.disabled = true;
        
        try {
            // Attempt registration
            const user = TopUpSystem.registerUser(userData);
            
            TopUpSystem.showMessage('Account created successfully! Please login.', 'success');
            
            // Redirect to login
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1500);
            
        } catch (error) {
            TopUpSystem.showMessage(error.message, 'error');
            
            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    });
}

// ===== DEMO ACCOUNT HANDLERS =====
function handleDemoAccounts() {
    // Demo user login
    const demoUserBtn = document.getElementById('demoUserBtn');
    if (demoUserBtn) {
        demoUserBtn.addEventListener('click', function() {
            document.getElementById('email').value = 'user@demo.com';
            document.getElementById('password').value = 'demo123';
            TopUpSystem.showMessage('Demo user credentials filled', 'info');
        });
    }
    
    // Demo admin login
    const demoAdminBtn = document.getElementById('demoAdminBtn');
    if (demoAdminBtn) {
        demoAdminBtn.addEventListener('click', function() {
            document.getElementById('email').value = 'admin@demo.com';
            document.getElementById('password').value = 'admin123';
            TopUpSystem.showMessage('Demo admin credentials filled', 'info');
        });
    }
}

// ===== PASSWORD VISIBILITY TOGGLE =====
function handlePasswordToggle() {
    const passwordToggles = document.querySelectorAll('.password-toggle');
    
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                input.type = 'password';
                icon.className = 'fas fa-eye';
            }
        });
    });
}

// ===== PASSWORD STRENGTH CHECKER =====
function handlePasswordStrength() {
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    
    passwordInputs.forEach(input => {
        if (input.name === 'password') {
            input.addEventListener('input', function() {
                const strength = checkPasswordStrength(this.value);
                updatePasswordStrengthUI(strength, this);
            });
        }
    });
}

function checkPasswordStrength(password) {
    let score = 0;
    let feedback = [];
    
    if (password.length >= 8) score++;
    else feedback.push('At least 8 characters');
    
    if (/[a-z]/.test(password)) score++;
    else feedback.push('Lowercase letter');
    
    if (/[A-Z]/.test(password)) score++;
    else feedback.push('Uppercase letter');
    
    if (/[0-9]/.test(password)) score++;
    else feedback.push('Number');
    
    if (/[^A-Za-z0-9]/.test(password)) score++;
    else feedback.push('Special character');
    
    let level = 'weak';
    if (score >= 4) level = 'strong';
    else if (score >= 2) level = 'medium';
    
    return { score, level, feedback };
}

function updatePasswordStrengthUI(strength, input) {
    let strengthEl = input.parentElement.querySelector('.password-strength');
    
    if (!strengthEl) {
        strengthEl = document.createElement('div');
        strengthEl.className = 'password-strength';
        input.parentElement.appendChild(strengthEl);
    }
    
    strengthEl.className = `password-strength strength-${strength.level}`;
    strengthEl.textContent = `Password strength: ${strength.level}`;
    
    if (strength.feedback.length > 0) {
        strengthEl.textContent += ` (Missing: ${strength.feedback.join(', ')})`;
    }
}

// ===== LOGOUT HANDLER =====
function handleLogout() {
    const logoutLinks = document.querySelectorAll('a[href="#logout"], .logout-btn');
    
    logoutLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (confirm('Are you sure you want to logout?')) {
                TopUpSystem.logoutUser();
                TopUpSystem.showMessage('Logged out successfully', 'success');
                
                setTimeout(() => {
                    window.location.href = '../index.html';
                }, 1000);
            }
        });
    });
}

// ===== FORM VALIDATION =====
function setupFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input[required]');
        
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateInput(this);
            });
            
            input.addEventListener('input', function() {
                if (this.classList.contains('error')) {
                    validateInput(this);
                }
            });
        });
    });
}

function validateInput(input) {
    const value = input.value.trim();
    let isValid = true;
    let errorMessage = '';
    
    // Required validation
    if (input.hasAttribute('required') && !value) {
        isValid = false;
        errorMessage = 'This field is required';
    }
    
    // Email validation
    if (input.type === 'email' && value && !TopUpSystem.validateEmail(value)) {
        isValid = false;
        errorMessage = 'Please enter a valid email address';
    }
    
    // Phone validation
    if (input.type === 'tel' && value && !TopUpSystem.validatePhone(value)) {
        isValid = false;
        errorMessage = 'Please enter a valid phone number';
    }
    
    // Password confirmation
    if (input.name === 'confirmPassword') {
        const passwordInput = input.form.querySelector('input[name="password"]');
        if (passwordInput && value !== passwordInput.value) {
            isValid = false;
            errorMessage = 'Passwords do not match';
        }
    }
    
    // Update UI
    if (isValid) {
        input.classList.remove('error');
        removeErrorMessage(input);
    } else {
        input.classList.add('error');
        showErrorMessage(input, errorMessage);
    }
    
    return isValid;
}

function showErrorMessage(input, message) {
    removeErrorMessage(input);
    
    const errorEl = document.createElement('div');
    errorEl.className = 'error-message';
    errorEl.textContent = message;
    errorEl.style.color = 'var(--danger-color)';
    errorEl.style.fontSize = '0.75rem';
    errorEl.style.marginTop = '0.25rem';
    
    input.parentElement.appendChild(errorEl);
}

function removeErrorMessage(input) {
    const existingError = input.parentElement.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
}

// ===== REDIRECT IF ALREADY LOGGED IN =====
function checkAuthRedirect() {
    if (TopUpSystem.isUserLoggedIn()) {
        const user = TopUpSystem.getCurrentUser();
        
        // Don't redirect if already on the correct page
        const currentPath = window.location.pathname;
        if (currentPath.includes('admin') && user.role === 'admin') return;
        if (currentPath.includes('user') && user.role === 'user') return;
        
        // Redirect to appropriate dashboard
        if (user.role === 'admin') {
            window.location.href = 'admin/index.html';
        } else {
            window.location.href = 'user/index.html';
        }
    }
}

// ===== INITIALIZATION =====
function initializeAuth() {
    // Check if user should be redirected
    checkAuthRedirect();
    
    // Setup form handlers
    handleLoginForm();
    handleRegistrationForm();
    handleDemoAccounts();
    handlePasswordToggle();
    handlePasswordStrength();
    handleLogout();
    setupFormValidation();
    
    console.log('Authentication module initialized');
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeAuth);
} else {
    initializeAuth();
}

